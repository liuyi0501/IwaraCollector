const util = require('../utils/common')
var fs = require('fs')
var axios = require('axios');
var cheerio = require('cheerio');
var schedule = require('node-schedule');

function GetVideo(url,thumb){
        if(url.indexOf("ecchi.iwara.tv")==-1){
            console.log("错误的路径请求：/utils/E-GetVideo.js")
            return 0;
        }else{
            html = axios.post(url, {//获取页面信息
                referer: 'https://ecchi.iwara.tv/',
                firstName: 'Fred',
                lastName: 'Flintstone',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
            }).then(response => {
                //console.log(response.data);
                data = response.data;
                //console.log("the result is" + data);
                var $ = cheerio.load(data);
                var title = $('body').find('h1').text();
                console.log('E视频标题为'+title);
                var description = $('.field-items').find('p').html();
                console.log('E视频简介为'+description);
                var DownloadAddr = url.replace('videos','api/video')
                console.log('E视频即时下载地址为'+DownloadAddr);
                var author = $('.node-info').find('a.username').text();
                console.log('E视频作者'+author)
                console.log("www缩略图"+thumb)
                console.log('E原视频地址'+url)
                description.replace(/\s/g,'');
                var json = '{"title":"'+title+'","author":"'+author+'","description":"'+ description.replace(/&|<|>|'|"/g, function(matchStr) {
                    var tokenMap = {
                    
                    '\n':'',
                    ':': '\\:',
                    '&': '&',
                    '<': '<',
                    '>': '>',
                    "'": '&apos;',
                    '"': '\''
                };
                    return tokenMap[matchStr];
                })+'","thumb":"'+thumb+'","download":"'+DownloadAddr+'","origin":"'+url+'"}'
                //配对视频代号
                var start_line = url.indexOf('/videos/');
                var id = "";
                for(i=0;i<url.length;i++){
                    if(i>=start_line+8){
                        id = id + url[i];
                    }
                }
                console.log("E视频id为"+id);
                fs.writeFileSync('./data/ecchi/'+id+'.json',json,function(err){
                    if(err)console.err(err)
                })
            })
            
        }
    }
/*
Example
GetVideo('https://ecchi.iwara.tv/videos/am0zatlr92s7w49vz',"undefined")
*/
GetVideo('https://ecchi.iwara.tv/videos/am0zatlr92s7w49vz',"undefined")
module.exports = {
    GetVideo,
}