const util = require('../utils/common')
var fs = require('fs')
var axios = require('axios');
var cheerio = require('cheerio');
var schedule = require('node-schedule');
var GetVideo = require('../utils/GetVideo')
var https = require("https");
var iconv = require("iconv-lite");

async function GetPage(LastPage, d) {
    if (!d) {
        d = 1;
    }
    try {
        https.get('https://www.iwara.tv/videos?page=' + d, function (res) {
            var datas = [];
            var size = 0;
            res.on('data', function (data) {
                datas.push(data);
                size += data.length;
                //process.stdout.write(data);  
            });
            res.on("end", function () {
                var buff = Buffer.concat(datas, size);
                var result = iconv.decode(buff, "utf8");//转码//var result = buff.toString();//不需要转编码,直接tostring  
                var data = result;
            //console.log("the result is" + data);
            var $ = cheerio.load(data);
            //console.log(pages.indexOf('page='))
            let video = []
            let thumb = []
            $('h3.title').each(function (i, ele) {
                video.push($(this).find('a').attr('href'))

            })
            $('.field-items').each(function (i, ele) {
                thumb.push($(this).find('img').attr('src'))
            })
            VideoGet(video, thumb);
            fs.writeFileSync('./data/www/page/'+d+'.json','{"video":["'+video.join('","')+'"]}', function (err) {
                if (err) console.log(err);
        })
            d++;
            if (d <= LastPage) GetPage(LastPage, d)
            });
        }).on("error", function (err) {
            console.error(err.stack)
            GetPage(LastPage, d);

        });
    } catch (err) {
        console.log(err);
        console.log("at ./utils/GetAllVideo.js:15")
        GetPage(LastPage, d);
    }
}
async function VideoGet(video, thumb, q) {
    if (!q) {
        q = 0
    }
    let second = Date.now();

    while (Number(Date.now()) <= Number(second) + 1000) {
        //等待1秒，什么都不做
    }
    console.log("---------")
    console.log("开始爬取视频" + video[q])
    try {
        https.get("https://www.iwara.tv" + video[q], function (res) {
            var datas = [];
            var size = 0;
            res.on('data', function (data) {
                datas.push(data);
                size += data.length;
                //process.stdout.write(data);  
            });
            res.on("end", function () {
                var buff = Buffer.concat(datas, size);
                var result = iconv.decode(buff, "utf8");//转码//var result = buff.toString();//不需要转编码,直接tostring  
                GetVideo("https://www.iwara.tv" + video[q], thumb[q], result)
                q++;
                if (q < video.length) VideoGet(video, thumb, q)
            });
        }).on("error", function (err) {
            console.error(err.stack)


        });
    } catch (err) {
        console.log(err);
        VideoGet(video, thumb, q)
    }
    




    return 1;
}

async function GetAllVideo() {
    
    console.log("开始发送第一页请求")
    html = axios.post('https://www.iwara.tv/videos', {//获取页面信息
        referer: 'https://www.iwara.tv/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
    }).then(response => {
        try{
        console.log("第一页请求发送并接收完毕")
        //console.log(response.data);
        var data = response.data;
        //console.log("the result is" + data);
        var $ = cheerio.load(data);
        var pages = $('.pager-last').find('a').attr("href")
        //console.log(pages.indexOf('page='))
        var start = pages.indexOf('page=')
        }catch(err){
            console.error(err)
            while (Number(Date.now()) <= Number(second) + 1000) {
        //等待1秒，什么都不做
    }
            GetAllVideo()
            return 0;
        }
        var PageLast = ""
        for (i = 0; i < pages.length; i++) {
            if (i >= start + 5) {
                PageLast = PageLast + pages[i]
            }
        }
    
        console.log('最后一页' + PageLast)
        fs.writeFileSync('./data/www/page/all.js','{"LastPage":"'+PageLast+'"}',function(err){
            if(err){
                console.error(err)
            }
        })
        let video = []
        let thumb = []
        $('h3.title').each(function (i, ele) {
            video.push($(this).find('a').attr('href'))

        })
        $('.field-items').each(function (i, ele) {
            thumb.push($(this).find('img').attr('src'))
        })
        VideoGet(video, thumb);
        fs.writeFileSync('./data/www/page/'+0+'.json','{"video":["'+video.join('","')+'"]}', function (err) {
                if (err) console.log(err);
        })

        GetPage(PageLast)
        //开始循环
        //循环获取
        /*
        for (t = 1; t <= PageLast; t++) {
            let second = Date.now();
            while (Number(Date.now()) <= Number(second) + 1000) {
                //等待1秒，什么都不做
            }
            html = axios.post('https://www.iwara.tv/videos?language=ja&page=' + t, {//获取页面信息
                referer: 'https://www.iwara.tv/',
                firstName: 'Fred',
                lastName: 'Flintstone',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
            }).then(response2 => {
                console.log("第%d页读取成功", t)
                let data2 = response2.data;
                //console.log("the result is" + data);
                let $2 = cheerio.load(data2);
                let video = []
                let thumb = []
                $2('h3.title').each(function (i, ele) {
                    video.push($2(this).find('a').attr('href'))

                })
                $2('.field-items').each(function (i, ele) {
                    thumb.push($2(this).find('img').attr('src'))
                })
            })
            VideoGet(video, thumb);
            fs.writeFileSync('./video.json', "["+video+"]", function (err) {
                if (err) console.log(err);
            })
            fs.writeFileSync('./thumb.json', "["+thumb+"]", function (err) {
                if (err) console.log(err);
            })
            /*
            for(o = 0 ; o < video.length ; o++){
                while(Date.now()<=second+1000){
                //等待0.1秒，什么都不做
                }
                GetVideo.GetVideo("https://www.iwara.tv"+video[o],thumb[o])
                console.log("获取%s视频成功",video[o]);
            }
            */
        //}


    })


}
GetAllVideo()

module.exports = {
    GetAllVideo,
}